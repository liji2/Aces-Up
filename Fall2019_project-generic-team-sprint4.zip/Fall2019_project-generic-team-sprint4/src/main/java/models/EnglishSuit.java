package models;

import java.io.Serializable;

/**
 * Created by michaelhilton on 1/25/16.
 */
public enum EnglishSuit implements Suit, Serializable {
    Hearts, Spades, Diamonds, Clubs
}

