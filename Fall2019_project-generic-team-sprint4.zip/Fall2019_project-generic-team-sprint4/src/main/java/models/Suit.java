package models;

import java.io.Serializable;

/**
 * Created by michaelhilton on 1/25/16.
 */
public interface Suit {
}